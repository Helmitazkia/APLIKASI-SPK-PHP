<footer>
    <div class="footer clearfix mb-0 text-muted">
        <div class="float-start">
            <p>2021 &copy; SPK - SAW Method</p>
        </div>
        <div class="float-end">
            <p>Crafted with <span class="text-danger"><i class="bi bi-heart"></i></span> by <a
                    href="http://github.com/rickyginting">Ricky Martin Ginting</a></p>
        </div>
    </div>
</footer>
